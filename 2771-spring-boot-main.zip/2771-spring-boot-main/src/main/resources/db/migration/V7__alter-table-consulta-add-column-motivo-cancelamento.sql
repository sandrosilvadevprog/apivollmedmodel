alter table consultas add column motivo_cancelamento varchar(100);
